﻿namespace SistemaDeHotelaria
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPrincipal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hóspedesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quartoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hóspedesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.hospedagensToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reservasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serviçosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.produtosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Info;
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(16, 100);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hóspedesToolStripMenuItem,
            this.quartoToolStripMenuItem,
            this.hóspedesToolStripMenuItem1,
            this.hospedagensToolStripMenuItem,
            this.reservasToolStripMenuItem,
            this.serviçosToolStripMenuItem,
            this.produtosToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1216, 87);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hóspedesToolStripMenuItem
            // 
            this.hóspedesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("hóspedesToolStripMenuItem.Image")));
            this.hóspedesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.hóspedesToolStripMenuItem.Name = "hóspedesToolStripMenuItem";
            this.hóspedesToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.hóspedesToolStripMenuItem.Size = new System.Drawing.Size(99, 83);
            this.hóspedesToolStripMenuItem.Text = "Funcionários";
            this.hóspedesToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.hóspedesToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // quartoToolStripMenuItem
            // 
            this.quartoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quartoToolStripMenuItem.Image")));
            this.quartoToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.quartoToolStripMenuItem.Name = "quartoToolStripMenuItem";
            this.quartoToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.quartoToolStripMenuItem.Size = new System.Drawing.Size(88, 83);
            this.quartoToolStripMenuItem.Text = "Quartos";
            this.quartoToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.quartoToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.quartoToolStripMenuItem.Click += new System.EventHandler(this.quartoToolStripMenuItem_Click);
            // 
            // hóspedesToolStripMenuItem1
            // 
            this.hóspedesToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("hóspedesToolStripMenuItem1.Image")));
            this.hóspedesToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.hóspedesToolStripMenuItem1.Name = "hóspedesToolStripMenuItem1";
            this.hóspedesToolStripMenuItem1.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.hóspedesToolStripMenuItem1.Size = new System.Drawing.Size(88, 83);
            this.hóspedesToolStripMenuItem1.Text = "Hóspedes";
            this.hóspedesToolStripMenuItem1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.hóspedesToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.hóspedesToolStripMenuItem1.Click += new System.EventHandler(this.hóspedesToolStripMenuItem1_Click);
            // 
            // hospedagensToolStripMenuItem
            // 
            this.hospedagensToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("hospedagensToolStripMenuItem.Image")));
            this.hospedagensToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.hospedagensToolStripMenuItem.Name = "hospedagensToolStripMenuItem";
            this.hospedagensToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.hospedagensToolStripMenuItem.Size = new System.Drawing.Size(103, 83);
            this.hospedagensToolStripMenuItem.Text = "Hospedagens";
            this.hospedagensToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.hospedagensToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.hospedagensToolStripMenuItem.Click += new System.EventHandler(this.hospedagensToolStripMenuItem_Click_1);
            // 
            // reservasToolStripMenuItem
            // 
            this.reservasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("reservasToolStripMenuItem.Image")));
            this.reservasToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.reservasToolStripMenuItem.Name = "reservasToolStripMenuItem";
            this.reservasToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.reservasToolStripMenuItem.Size = new System.Drawing.Size(88, 83);
            this.reservasToolStripMenuItem.Text = "Reservas";
            this.reservasToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.reservasToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.reservasToolStripMenuItem.Click += new System.EventHandler(this.reservasToolStripMenuItem_Click);
            // 
            // serviçosToolStripMenuItem
            // 
            this.serviçosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("serviçosToolStripMenuItem.Image")));
            this.serviçosToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.serviçosToolStripMenuItem.Name = "serviçosToolStripMenuItem";
            this.serviçosToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.serviçosToolStripMenuItem.Size = new System.Drawing.Size(88, 83);
            this.serviçosToolStripMenuItem.Text = "Serviços";
            this.serviçosToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.serviçosToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.serviçosToolStripMenuItem.Click += new System.EventHandler(this.serviçosToolStripMenuItem_Click);
            // 
            // produtosToolStripMenuItem
            // 
            this.produtosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("produtosToolStripMenuItem.Image")));
            this.produtosToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.produtosToolStripMenuItem.Name = "produtosToolStripMenuItem";
            this.produtosToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.produtosToolStripMenuItem.Size = new System.Drawing.Size(88, 83);
            this.produtosToolStripMenuItem.Text = "Produtos";
            this.produtosToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.produtosToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.produtosToolStripMenuItem.Click += new System.EventHandler(this.produtosToolStripMenuItem_Click_2);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1216, 495);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema de Hotelaria";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hóspedesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quartoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hóspedesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem hospedagensToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reservasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serviçosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem produtosToolStripMenuItem;
    }
}