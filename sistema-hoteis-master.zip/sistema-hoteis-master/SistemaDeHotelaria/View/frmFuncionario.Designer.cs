﻿namespace SistemaDeHotelaria
{
    partial class frmFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblEstadoFunc = new System.Windows.Forms.Label();
            this.cbEstadoFunc = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSalarioFunc = new System.Windows.Forms.TextBox();
            this.cbStatusFunc = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSenhaFunc = new System.Windows.Forms.TextBox();
            this.lblLogin = new System.Windows.Forms.Label();
            this.txtLoginFunc = new System.Windows.Forms.TextBox();
            this.txtCodigoFunc = new System.Windows.Forms.TextBox();
            this.maskCPFFunc = new System.Windows.Forms.MaskedTextBox();
            this.lblIDFunc = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.cbCidadeFunc = new System.Windows.Forms.ComboBox();
            this.btnCancelarFunc = new System.Windows.Forms.Button();
            this.btnSalvarFunc = new System.Windows.Forms.Button();
            this.btnNovoFunc = new System.Windows.Forms.Button();
            this.btnExcluirFunc = new System.Windows.Forms.Button();
            this.btnAlterarFunc = new System.Windows.Forms.Button();
            this.gbBuscaFuncionario = new System.Windows.Forms.GroupBox();
            this.rbTodosBuscaFunc = new System.Windows.Forms.RadioButton();
            this.btnBuscarFunc = new System.Windows.Forms.Button();
            this.rbCodigoBuscaFunc = new System.Windows.Forms.RadioButton();
            this.rbCPFBuscaFunc = new System.Windows.Forms.RadioButton();
            this.maskBuscaCpf = new System.Windows.Forms.MaskedTextBox();
            this.rbNomeBuscaFunc = new System.Windows.Forms.RadioButton();
            this.lblCpfBuscaFunc = new System.Windows.Forms.Label();
            this.txtBuscaCodigo = new System.Windows.Forms.TextBox();
            this.lblCodigoBuscaFunc = new System.Windows.Forms.Label();
            this.txtBuscaNome = new System.Windows.Forms.TextBox();
            this.lblNomeBuscaFunc = new System.Windows.Forms.Label();
            this.maskCelularFunc = new System.Windows.Forms.MaskedTextBox();
            this.maskTelefoneFunc = new System.Windows.Forms.MaskedTextBox();
            this.txtComplementoFunc = new System.Windows.Forms.TextBox();
            this.txtBairroFunc = new System.Windows.Forms.TextBox();
            this.txtNumeroFunc = new System.Windows.Forms.TextBox();
            this.txtLogradouroFunc = new System.Windows.Forms.TextBox();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.maskCEPFunc = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblCpfFunc = new System.Windows.Forms.Label();
            this.lblComplementoFunc = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblBairroFunc = new System.Windows.Forms.Label();
            this.lblNumeroFunc = new System.Windows.Forms.Label();
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblLogradouroFunc = new System.Windows.Forms.Label();
            this.dgFuncionario = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbBuscaFuncionario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFuncionario)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblEstadoFunc);
            this.panel1.Controls.Add(this.cbEstadoFunc);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.txtCodigoFunc);
            this.panel1.Controls.Add(this.maskCPFFunc);
            this.panel1.Controls.Add(this.lblIDFunc);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.cbCidadeFunc);
            this.panel1.Controls.Add(this.btnCancelarFunc);
            this.panel1.Controls.Add(this.btnSalvarFunc);
            this.panel1.Controls.Add(this.btnNovoFunc);
            this.panel1.Controls.Add(this.btnExcluirFunc);
            this.panel1.Controls.Add(this.btnAlterarFunc);
            this.panel1.Controls.Add(this.gbBuscaFuncionario);
            this.panel1.Controls.Add(this.maskCelularFunc);
            this.panel1.Controls.Add(this.maskTelefoneFunc);
            this.panel1.Controls.Add(this.txtComplementoFunc);
            this.panel1.Controls.Add(this.txtBairroFunc);
            this.panel1.Controls.Add(this.txtNumeroFunc);
            this.panel1.Controls.Add(this.txtLogradouroFunc);
            this.panel1.Controls.Add(this.txtNomeFunc);
            this.panel1.Controls.Add(this.maskCEPFunc);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.lblCpfFunc);
            this.panel1.Controls.Add(this.lblComplementoFunc);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.lblBairroFunc);
            this.panel1.Controls.Add(this.lblNumeroFunc);
            this.panel1.Controls.Add(this.lblNomeFunc);
            this.panel1.Controls.Add(this.lblLogradouroFunc);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(862, 300);
            this.panel1.TabIndex = 140;
            // 
            // lblEstadoFunc
            // 
            this.lblEstadoFunc.AutoSize = true;
            this.lblEstadoFunc.Location = new System.Drawing.Point(259, 113);
            this.lblEstadoFunc.Name = "lblEstadoFunc";
            this.lblEstadoFunc.Size = new System.Drawing.Size(40, 13);
            this.lblEstadoFunc.TabIndex = 179;
            this.lblEstadoFunc.Text = "Estado";
            // 
            // cbEstadoFunc
            // 
            this.cbEstadoFunc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbEstadoFunc.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbEstadoFunc.FormattingEnabled = true;
            this.cbEstadoFunc.Location = new System.Drawing.Point(262, 130);
            this.cbEstadoFunc.Name = "cbEstadoFunc";
            this.cbEstadoFunc.Size = new System.Drawing.Size(43, 21);
            this.cbEstadoFunc.TabIndex = 9;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtSalarioFunc);
            this.groupBox2.Controls.Add(this.cbStatusFunc);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(16, 169);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(261, 73);
            this.groupBox2.TabIndex = 141;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Funcionário";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(147, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 173;
            this.label2.Text = "Salário";
            // 
            // txtSalarioFunc
            // 
            this.txtSalarioFunc.Location = new System.Drawing.Point(150, 37);
            this.txtSalarioFunc.Name = "txtSalarioFunc";
            this.txtSalarioFunc.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioFunc.TabIndex = 14;
            // 
            // cbStatusFunc
            // 
            this.cbStatusFunc.FormattingEnabled = true;
            this.cbStatusFunc.Items.AddRange(new object[] {
            "Ativo",
            "Inativo",
            "Afastado"});
            this.cbStatusFunc.Location = new System.Drawing.Point(9, 37);
            this.cbStatusFunc.Name = "cbStatusFunc";
            this.cbStatusFunc.Size = new System.Drawing.Size(121, 21);
            this.cbStatusFunc.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 172;
            this.label1.Text = "Status";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtSenhaFunc);
            this.groupBox1.Controls.Add(this.lblLogin);
            this.groupBox1.Controls.Add(this.txtLoginFunc);
            this.groupBox1.Location = new System.Drawing.Point(294, 167);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(319, 75);
            this.groupBox1.TabIndex = 177;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Acesso ao sistema";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(173, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 175;
            this.label3.Text = "Senha";
            // 
            // txtSenhaFunc
            // 
            this.txtSenhaFunc.Location = new System.Drawing.Point(172, 39);
            this.txtSenhaFunc.Name = "txtSenhaFunc";
            this.txtSenhaFunc.PasswordChar = '*';
            this.txtSenhaFunc.Size = new System.Drawing.Size(131, 20);
            this.txtSenhaFunc.TabIndex = 16;
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.Location = new System.Drawing.Point(12, 23);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(33, 13);
            this.lblLogin.TabIndex = 170;
            this.lblLogin.Text = "Login";
            // 
            // txtLoginFunc
            // 
            this.txtLoginFunc.Location = new System.Drawing.Point(15, 39);
            this.txtLoginFunc.Name = "txtLoginFunc";
            this.txtLoginFunc.Size = new System.Drawing.Size(133, 20);
            this.txtLoginFunc.TabIndex = 15;
            // 
            // txtCodigoFunc
            // 
            this.txtCodigoFunc.Location = new System.Drawing.Point(16, 35);
            this.txtCodigoFunc.Name = "txtCodigoFunc";
            this.txtCodigoFunc.Size = new System.Drawing.Size(43, 20);
            this.txtCodigoFunc.TabIndex = 1;
            // 
            // maskCPFFunc
            // 
            this.maskCPFFunc.Location = new System.Drawing.Point(519, 35);
            this.maskCPFFunc.Mask = "000,000,000-00";
            this.maskCPFFunc.Name = "maskCPFFunc";
            this.maskCPFFunc.Size = new System.Drawing.Size(95, 20);
            this.maskCPFFunc.TabIndex = 3;
            // 
            // lblIDFunc
            // 
            this.lblIDFunc.AutoSize = true;
            this.lblIDFunc.Location = new System.Drawing.Point(13, 19);
            this.lblIDFunc.Name = "lblIDFunc";
            this.lblIDFunc.Size = new System.Drawing.Size(18, 13);
            this.lblIDFunc.TabIndex = 166;
            this.lblIDFunc.Text = "ID";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(124, 113);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 165;
            this.label14.Text = "Cidade";
            // 
            // cbCidadeFunc
            // 
            this.cbCidadeFunc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbCidadeFunc.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbCidadeFunc.FormattingEnabled = true;
            this.cbCidadeFunc.Location = new System.Drawing.Point(127, 130);
            this.cbCidadeFunc.Name = "cbCidadeFunc";
            this.cbCidadeFunc.Size = new System.Drawing.Size(121, 21);
            this.cbCidadeFunc.TabIndex = 8;
            // 
            // btnCancelarFunc
            // 
            this.btnCancelarFunc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancelarFunc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelarFunc.Location = new System.Drawing.Point(268, 255);
            this.btnCancelarFunc.Name = "btnCancelarFunc";
            this.btnCancelarFunc.Size = new System.Drawing.Size(78, 32);
            this.btnCancelarFunc.TabIndex = 20;
            this.btnCancelarFunc.Text = "Cancelar";
            this.btnCancelarFunc.UseVisualStyleBackColor = false;
            this.btnCancelarFunc.Click += new System.EventHandler(this.btnCancelarFunc_Click);
            // 
            // btnSalvarFunc
            // 
            this.btnSalvarFunc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSalvarFunc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalvarFunc.Location = new System.Drawing.Point(184, 255);
            this.btnSalvarFunc.Name = "btnSalvarFunc";
            this.btnSalvarFunc.Size = new System.Drawing.Size(78, 32);
            this.btnSalvarFunc.TabIndex = 19;
            this.btnSalvarFunc.Text = "Salvar";
            this.btnSalvarFunc.UseVisualStyleBackColor = false;
            this.btnSalvarFunc.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnNovoFunc
            // 
            this.btnNovoFunc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnNovoFunc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovoFunc.Location = new System.Drawing.Point(16, 255);
            this.btnNovoFunc.Name = "btnNovoFunc";
            this.btnNovoFunc.Size = new System.Drawing.Size(78, 32);
            this.btnNovoFunc.TabIndex = 17;
            this.btnNovoFunc.Text = "Novo";
            this.btnNovoFunc.UseVisualStyleBackColor = false;
            this.btnNovoFunc.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnExcluirFunc
            // 
            this.btnExcluirFunc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnExcluirFunc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluirFunc.Location = new System.Drawing.Point(352, 255);
            this.btnExcluirFunc.Name = "btnExcluirFunc";
            this.btnExcluirFunc.Size = new System.Drawing.Size(78, 32);
            this.btnExcluirFunc.TabIndex = 21;
            this.btnExcluirFunc.Text = "Excluir";
            this.btnExcluirFunc.UseVisualStyleBackColor = false;
            this.btnExcluirFunc.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnAlterarFunc
            // 
            this.btnAlterarFunc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAlterarFunc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlterarFunc.Location = new System.Drawing.Point(100, 255);
            this.btnAlterarFunc.Name = "btnAlterarFunc";
            this.btnAlterarFunc.Size = new System.Drawing.Size(78, 32);
            this.btnAlterarFunc.TabIndex = 18;
            this.btnAlterarFunc.Text = "Alterar";
            this.btnAlterarFunc.UseVisualStyleBackColor = false;
            this.btnAlterarFunc.Click += new System.EventHandler(this.btnAlterarFunc_Click);
            // 
            // gbBuscaFuncionario
            // 
            this.gbBuscaFuncionario.Controls.Add(this.rbTodosBuscaFunc);
            this.gbBuscaFuncionario.Controls.Add(this.btnBuscarFunc);
            this.gbBuscaFuncionario.Controls.Add(this.rbCodigoBuscaFunc);
            this.gbBuscaFuncionario.Controls.Add(this.rbCPFBuscaFunc);
            this.gbBuscaFuncionario.Controls.Add(this.maskBuscaCpf);
            this.gbBuscaFuncionario.Controls.Add(this.rbNomeBuscaFunc);
            this.gbBuscaFuncionario.Controls.Add(this.lblCpfBuscaFunc);
            this.gbBuscaFuncionario.Controls.Add(this.txtBuscaCodigo);
            this.gbBuscaFuncionario.Controls.Add(this.lblCodigoBuscaFunc);
            this.gbBuscaFuncionario.Controls.Add(this.txtBuscaNome);
            this.gbBuscaFuncionario.Controls.Add(this.lblNomeBuscaFunc);
            this.gbBuscaFuncionario.Location = new System.Drawing.Point(627, 19);
            this.gbBuscaFuncionario.Name = "gbBuscaFuncionario";
            this.gbBuscaFuncionario.Size = new System.Drawing.Size(215, 223);
            this.gbBuscaFuncionario.TabIndex = 159;
            this.gbBuscaFuncionario.TabStop = false;
            this.gbBuscaFuncionario.Text = "Buscar Funcionário";
            // 
            // rbTodosBuscaFunc
            // 
            this.rbTodosBuscaFunc.AutoSize = true;
            this.rbTodosBuscaFunc.Location = new System.Drawing.Point(9, 185);
            this.rbTodosBuscaFunc.Name = "rbTodosBuscaFunc";
            this.rbTodosBuscaFunc.Size = new System.Drawing.Size(55, 17);
            this.rbTodosBuscaFunc.TabIndex = 27;
            this.rbTodosBuscaFunc.TabStop = true;
            this.rbTodosBuscaFunc.Text = "Todos";
            this.rbTodosBuscaFunc.UseVisualStyleBackColor = true;
            // 
            // btnBuscarFunc
            // 
            this.btnBuscarFunc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnBuscarFunc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarFunc.Location = new System.Drawing.Point(131, 161);
            this.btnBuscarFunc.Name = "btnBuscarFunc";
            this.btnBuscarFunc.Size = new System.Drawing.Size(78, 32);
            this.btnBuscarFunc.TabIndex = 29;
            this.btnBuscarFunc.Text = "Buscar";
            this.btnBuscarFunc.UseVisualStyleBackColor = false;
            // 
            // rbCodigoBuscaFunc
            // 
            this.rbCodigoBuscaFunc.AutoSize = true;
            this.rbCodigoBuscaFunc.Location = new System.Drawing.Point(9, 150);
            this.rbCodigoBuscaFunc.Name = "rbCodigoBuscaFunc";
            this.rbCodigoBuscaFunc.Size = new System.Drawing.Size(58, 17);
            this.rbCodigoBuscaFunc.TabIndex = 25;
            this.rbCodigoBuscaFunc.TabStop = true;
            this.rbCodigoBuscaFunc.Text = "Código";
            this.rbCodigoBuscaFunc.UseVisualStyleBackColor = true;
            // 
            // rbCPFBuscaFunc
            // 
            this.rbCPFBuscaFunc.AutoSize = true;
            this.rbCPFBuscaFunc.Location = new System.Drawing.Point(71, 185);
            this.rbCPFBuscaFunc.Name = "rbCPFBuscaFunc";
            this.rbCPFBuscaFunc.Size = new System.Drawing.Size(45, 17);
            this.rbCPFBuscaFunc.TabIndex = 28;
            this.rbCPFBuscaFunc.TabStop = true;
            this.rbCPFBuscaFunc.Text = "CPF";
            this.rbCPFBuscaFunc.UseVisualStyleBackColor = true;
            // 
            // maskBuscaCpf
            // 
            this.maskBuscaCpf.Location = new System.Drawing.Point(9, 114);
            this.maskBuscaCpf.Mask = "000.000.000-00";
            this.maskBuscaCpf.Name = "maskBuscaCpf";
            this.maskBuscaCpf.Size = new System.Drawing.Size(129, 20);
            this.maskBuscaCpf.TabIndex = 24;
            // 
            // rbNomeBuscaFunc
            // 
            this.rbNomeBuscaFunc.AutoSize = true;
            this.rbNomeBuscaFunc.Location = new System.Drawing.Point(71, 150);
            this.rbNomeBuscaFunc.Name = "rbNomeBuscaFunc";
            this.rbNomeBuscaFunc.Size = new System.Drawing.Size(53, 17);
            this.rbNomeBuscaFunc.TabIndex = 26;
            this.rbNomeBuscaFunc.TabStop = true;
            this.rbNomeBuscaFunc.Text = "Nome";
            this.rbNomeBuscaFunc.UseVisualStyleBackColor = true;
            // 
            // lblCpfBuscaFunc
            // 
            this.lblCpfBuscaFunc.AutoSize = true;
            this.lblCpfBuscaFunc.Location = new System.Drawing.Point(6, 98);
            this.lblCpfBuscaFunc.Name = "lblCpfBuscaFunc";
            this.lblCpfBuscaFunc.Size = new System.Drawing.Size(27, 13);
            this.lblCpfBuscaFunc.TabIndex = 21;
            this.lblCpfBuscaFunc.Text = "CPF";
            // 
            // txtBuscaCodigo
            // 
            this.txtBuscaCodigo.Location = new System.Drawing.Point(9, 35);
            this.txtBuscaCodigo.Name = "txtBuscaCodigo";
            this.txtBuscaCodigo.Size = new System.Drawing.Size(48, 20);
            this.txtBuscaCodigo.TabIndex = 22;
            // 
            // lblCodigoBuscaFunc
            // 
            this.lblCodigoBuscaFunc.AutoSize = true;
            this.lblCodigoBuscaFunc.Location = new System.Drawing.Point(6, 19);
            this.lblCodigoBuscaFunc.Name = "lblCodigoBuscaFunc";
            this.lblCodigoBuscaFunc.Size = new System.Drawing.Size(40, 13);
            this.lblCodigoBuscaFunc.TabIndex = 21;
            this.lblCodigoBuscaFunc.Text = "Código";
            // 
            // txtBuscaNome
            // 
            this.txtBuscaNome.Location = new System.Drawing.Point(9, 75);
            this.txtBuscaNome.Name = "txtBuscaNome";
            this.txtBuscaNome.Size = new System.Drawing.Size(173, 20);
            this.txtBuscaNome.TabIndex = 23;
            // 
            // lblNomeBuscaFunc
            // 
            this.lblNomeBuscaFunc.AutoSize = true;
            this.lblNomeBuscaFunc.Location = new System.Drawing.Point(6, 59);
            this.lblNomeBuscaFunc.Name = "lblNomeBuscaFunc";
            this.lblNomeBuscaFunc.Size = new System.Drawing.Size(35, 13);
            this.lblNomeBuscaFunc.TabIndex = 21;
            this.lblNomeBuscaFunc.Text = "Nome";
            // 
            // maskCelularFunc
            // 
            this.maskCelularFunc.Location = new System.Drawing.Point(518, 131);
            this.maskCelularFunc.Mask = "(00) 0000-0000";
            this.maskCelularFunc.Name = "maskCelularFunc";
            this.maskCelularFunc.Size = new System.Drawing.Size(95, 20);
            this.maskCelularFunc.TabIndex = 12;
            // 
            // maskTelefoneFunc
            // 
            this.maskTelefoneFunc.Location = new System.Drawing.Point(408, 131);
            this.maskTelefoneFunc.Mask = "(00) 0000-0000";
            this.maskTelefoneFunc.Name = "maskTelefoneFunc";
            this.maskTelefoneFunc.Size = new System.Drawing.Size(95, 20);
            this.maskTelefoneFunc.TabIndex = 11;
            // 
            // txtComplementoFunc
            // 
            this.txtComplementoFunc.Location = new System.Drawing.Point(16, 131);
            this.txtComplementoFunc.Name = "txtComplementoFunc";
            this.txtComplementoFunc.Size = new System.Drawing.Size(99, 20);
            this.txtComplementoFunc.TabIndex = 7;
            // 
            // txtBairroFunc
            // 
            this.txtBairroFunc.Location = new System.Drawing.Point(485, 84);
            this.txtBairroFunc.Name = "txtBairroFunc";
            this.txtBairroFunc.Size = new System.Drawing.Size(128, 20);
            this.txtBairroFunc.TabIndex = 6;
            // 
            // txtNumeroFunc
            // 
            this.txtNumeroFunc.Location = new System.Drawing.Point(421, 84);
            this.txtNumeroFunc.Name = "txtNumeroFunc";
            this.txtNumeroFunc.Size = new System.Drawing.Size(43, 20);
            this.txtNumeroFunc.TabIndex = 5;
            // 
            // txtLogradouroFunc
            // 
            this.txtLogradouroFunc.Location = new System.Drawing.Point(16, 84);
            this.txtLogradouroFunc.Name = "txtLogradouroFunc";
            this.txtLogradouroFunc.Size = new System.Drawing.Size(384, 20);
            this.txtLogradouroFunc.TabIndex = 4;
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(74, 35);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(418, 20);
            this.txtNomeFunc.TabIndex = 2;
            // 
            // maskCEPFunc
            // 
            this.maskCEPFunc.Location = new System.Drawing.Point(318, 131);
            this.maskCEPFunc.Mask = "00000-9999";
            this.maskCEPFunc.Name = "maskCEPFunc";
            this.maskCEPFunc.Size = new System.Drawing.Size(77, 20);
            this.maskCEPFunc.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(515, 115);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 13);
            this.label10.TabIndex = 158;
            this.label10.Text = "Celular";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(405, 115);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 157;
            this.label9.Text = "Telefone";
            // 
            // lblCpfFunc
            // 
            this.lblCpfFunc.AutoSize = true;
            this.lblCpfFunc.Location = new System.Drawing.Point(519, 19);
            this.lblCpfFunc.Name = "lblCpfFunc";
            this.lblCpfFunc.Size = new System.Drawing.Size(27, 13);
            this.lblCpfFunc.TabIndex = 156;
            this.lblCpfFunc.Text = "CPF";
            // 
            // lblComplementoFunc
            // 
            this.lblComplementoFunc.AutoSize = true;
            this.lblComplementoFunc.Location = new System.Drawing.Point(13, 115);
            this.lblComplementoFunc.Name = "lblComplementoFunc";
            this.lblComplementoFunc.Size = new System.Drawing.Size(71, 13);
            this.lblComplementoFunc.TabIndex = 155;
            this.lblComplementoFunc.Text = "Complemento";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(316, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 154;
            this.label6.Text = "CEP";
            // 
            // lblBairroFunc
            // 
            this.lblBairroFunc.AutoSize = true;
            this.lblBairroFunc.Location = new System.Drawing.Point(482, 68);
            this.lblBairroFunc.Name = "lblBairroFunc";
            this.lblBairroFunc.Size = new System.Drawing.Size(34, 13);
            this.lblBairroFunc.TabIndex = 153;
            this.lblBairroFunc.Text = "Bairro";
            // 
            // lblNumeroFunc
            // 
            this.lblNumeroFunc.AutoSize = true;
            this.lblNumeroFunc.Location = new System.Drawing.Point(417, 68);
            this.lblNumeroFunc.Name = "lblNumeroFunc";
            this.lblNumeroFunc.Size = new System.Drawing.Size(44, 13);
            this.lblNumeroFunc.TabIndex = 152;
            this.lblNumeroFunc.Text = "Número";
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Location = new System.Drawing.Point(71, 19);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(35, 13);
            this.lblNomeFunc.TabIndex = 150;
            this.lblNomeFunc.Text = "Nome";
            // 
            // lblLogradouroFunc
            // 
            this.lblLogradouroFunc.AutoSize = true;
            this.lblLogradouroFunc.Location = new System.Drawing.Point(13, 68);
            this.lblLogradouroFunc.Name = "lblLogradouroFunc";
            this.lblLogradouroFunc.Size = new System.Drawing.Size(61, 13);
            this.lblLogradouroFunc.TabIndex = 151;
            this.lblLogradouroFunc.Text = "Logradouro";
            // 
            // dgFuncionario
            // 
            this.dgFuncionario.AllowUserToAddRows = false;
            this.dgFuncionario.AllowUserToDeleteRows = false;
            this.dgFuncionario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgFuncionario.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgFuncionario.Location = new System.Drawing.Point(0, 300);
            this.dgFuncionario.Name = "dgFuncionario";
            this.dgFuncionario.ReadOnly = true;
            this.dgFuncionario.Size = new System.Drawing.Size(862, 175);
            this.dgFuncionario.TabIndex = 141;
            this.dgFuncionario.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // frmFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 475);
            this.Controls.Add(this.dgFuncionario);
            this.Controls.Add(this.panel1);
            this.Name = "frmFuncionario";
            this.Text = "Cadastro de Funcionário";
            this.Load += new System.EventHandler(this.frmFuncionario_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbBuscaFuncionario.ResumeLayout(false);
            this.gbBuscaFuncionario.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFuncionario)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtCodigoFunc;
        private System.Windows.Forms.MaskedTextBox maskCPFFunc;
        private System.Windows.Forms.Label lblIDFunc;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cbCidadeFunc;
        private System.Windows.Forms.Button btnCancelarFunc;
        private System.Windows.Forms.Button btnSalvarFunc;
        private System.Windows.Forms.Button btnNovoFunc;
        private System.Windows.Forms.Button btnExcluirFunc;
        private System.Windows.Forms.Button btnAlterarFunc;
        private System.Windows.Forms.GroupBox gbBuscaFuncionario;
        private System.Windows.Forms.RadioButton rbTodosBuscaFunc;
        private System.Windows.Forms.Button btnBuscarFunc;
        private System.Windows.Forms.RadioButton rbCodigoBuscaFunc;
        private System.Windows.Forms.RadioButton rbCPFBuscaFunc;
        private System.Windows.Forms.MaskedTextBox maskBuscaCpf;
        private System.Windows.Forms.RadioButton rbNomeBuscaFunc;
        private System.Windows.Forms.Label lblCpfBuscaFunc;
        private System.Windows.Forms.TextBox txtBuscaCodigo;
        private System.Windows.Forms.Label lblCodigoBuscaFunc;
        private System.Windows.Forms.TextBox txtBuscaNome;
        private System.Windows.Forms.Label lblNomeBuscaFunc;
        private System.Windows.Forms.MaskedTextBox maskCelularFunc;
        private System.Windows.Forms.MaskedTextBox maskTelefoneFunc;
        private System.Windows.Forms.TextBox txtComplementoFunc;
        private System.Windows.Forms.TextBox txtBairroFunc;
        private System.Windows.Forms.TextBox txtNumeroFunc;
        private System.Windows.Forms.TextBox txtLogradouroFunc;
        private System.Windows.Forms.TextBox txtNomeFunc;
        private System.Windows.Forms.MaskedTextBox maskCEPFunc;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblCpfFunc;
        private System.Windows.Forms.Label lblComplementoFunc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblBairroFunc;
        private System.Windows.Forms.Label lblNumeroFunc;
        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.Label lblLogradouroFunc;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSenhaFunc;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.TextBox txtLoginFunc;
        private System.Windows.Forms.TextBox txtSalarioFunc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbStatusFunc;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgFuncionario;
        private System.Windows.Forms.Label lblEstadoFunc;
        private System.Windows.Forms.ComboBox cbEstadoFunc;
    }
}