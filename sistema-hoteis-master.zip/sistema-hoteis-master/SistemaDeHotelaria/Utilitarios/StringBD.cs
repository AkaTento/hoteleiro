﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaDeHotelaria.Utilitarios
{
    class StringBD
    {
        //public static string stringConexao = "Data Source=DESKTOP-K0O0JOH;Initial Catalog = bdHotel; Integrated Security = True";
        //public static string nomeString = "ConnectionDB";
        public static string stringConexao = @"Data Source=DESKTOP-9GUVKU6\SQLEXPRESS;Initial Catalog=bdHotel;Integrated Security=True";
        public static string nomeString = "SistemaDeHotelaria.Properties.Settings.bdHotelConnectionString";
    }
}
